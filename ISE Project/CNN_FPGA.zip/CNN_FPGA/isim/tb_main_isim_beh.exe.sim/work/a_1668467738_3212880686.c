/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/FPGA/CNN_FPGA/find_max.vhd";
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_2563015576_1035706684(char *, char *, int , int );
unsigned char ieee_p_1242562249_sub_4081755647_1035706684(char *, char *, char *, char *, char *);


static void work_a_1668467738_3212880686_p_0(char *t0)
{
    char t27[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned char t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    unsigned char t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;

LAB0:    xsi_set_current_line(31, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)0);
    if (t4 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(44, ng0);
    t1 = ieee_p_1242562249_sub_2563015576_1035706684(IEEE_P_1242562249, t27, 0, 14);
    t3 = (14U != 14U);
    if (t3 == 1)
        goto LAB38;

LAB39:    t2 = (t0 + 3392);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t1, 14U);
    xsi_driver_first_trans_fast_port(t2);

LAB3:    t1 = (t0 + 3312);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(32, ng0);
    t1 = (t0 + 1192U);
    t7 = *((char **)t1);
    t1 = (t0 + 5024U);
    t8 = (t0 + 1352U);
    t9 = *((char **)t8);
    t8 = (t0 + 5040U);
    t10 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t7, t1, t9, t8);
    if (t10 == 1)
        goto LAB11;

LAB12:    t6 = (unsigned char)0;

LAB13:    if (t6 == 1)
        goto LAB8;

LAB9:    t5 = (unsigned char)0;

LAB10:    if (t5 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 5040U);
    t7 = (t0 + 1192U);
    t8 = *((char **)t7);
    t7 = (t0 + 5024U);
    t5 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t2, t1, t8, t7);
    if (t5 == 1)
        goto LAB19;

LAB20:    t4 = (unsigned char)0;

LAB21:    if (t4 == 1)
        goto LAB16;

LAB17:    t3 = (unsigned char)0;

LAB18:    if (t3 != 0)
        goto LAB14;

LAB15:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t1 = (t0 + 5056U);
    t7 = (t0 + 1192U);
    t8 = *((char **)t7);
    t7 = (t0 + 5024U);
    t5 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t2, t1, t8, t7);
    if (t5 == 1)
        goto LAB27;

LAB28:    t4 = (unsigned char)0;

LAB29:    if (t4 == 1)
        goto LAB24;

LAB25:    t3 = (unsigned char)0;

LAB26:    if (t3 != 0)
        goto LAB22;

LAB23:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 5072U);
    t7 = (t0 + 1192U);
    t8 = *((char **)t7);
    t7 = (t0 + 5024U);
    t5 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t2, t1, t8, t7);
    if (t5 == 1)
        goto LAB35;

LAB36:    t4 = (unsigned char)0;

LAB37:    if (t4 == 1)
        goto LAB32;

LAB33:    t3 = (unsigned char)0;

LAB34:    if (t3 != 0)
        goto LAB30;

LAB31:    xsi_set_current_line(41, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 3392);
    t7 = (t1 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t2, 14U);
    xsi_driver_first_trans_fast_port(t1);

LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(33, ng0);
    t21 = (t0 + 1192U);
    t22 = *((char **)t21);
    t21 = (t0 + 3392);
    t23 = (t21 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memcpy(t26, t22, 14U);
    xsi_driver_first_trans_fast_port(t21);
    goto LAB6;

LAB8:    t16 = (t0 + 1192U);
    t17 = *((char **)t16);
    t16 = (t0 + 5024U);
    t18 = (t0 + 1672U);
    t19 = *((char **)t18);
    t18 = (t0 + 5072U);
    t20 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t17, t16, t19, t18);
    t5 = t20;
    goto LAB10;

LAB11:    t11 = (t0 + 1192U);
    t12 = *((char **)t11);
    t11 = (t0 + 5024U);
    t13 = (t0 + 1512U);
    t14 = *((char **)t13);
    t13 = (t0 + 5056U);
    t15 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t12, t11, t14, t13);
    t6 = t15;
    goto LAB13;

LAB14:    xsi_set_current_line(35, ng0);
    t19 = (t0 + 1352U);
    t21 = *((char **)t19);
    t19 = (t0 + 3392);
    t22 = (t19 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t21, 14U);
    xsi_driver_first_trans_fast_port(t19);
    goto LAB6;

LAB16:    t14 = (t0 + 1352U);
    t16 = *((char **)t14);
    t14 = (t0 + 5040U);
    t17 = (t0 + 1672U);
    t18 = *((char **)t17);
    t17 = (t0 + 5072U);
    t10 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t16, t14, t18, t17);
    t3 = t10;
    goto LAB18;

LAB19:    t9 = (t0 + 1352U);
    t11 = *((char **)t9);
    t9 = (t0 + 5040U);
    t12 = (t0 + 1512U);
    t13 = *((char **)t12);
    t12 = (t0 + 5056U);
    t6 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t11, t9, t13, t12);
    t4 = t6;
    goto LAB21;

LAB22:    xsi_set_current_line(37, ng0);
    t19 = (t0 + 1512U);
    t21 = *((char **)t19);
    t19 = (t0 + 3392);
    t22 = (t19 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t21, 14U);
    xsi_driver_first_trans_fast_port(t19);
    goto LAB6;

LAB24:    t14 = (t0 + 1512U);
    t16 = *((char **)t14);
    t14 = (t0 + 5056U);
    t17 = (t0 + 1672U);
    t18 = *((char **)t17);
    t17 = (t0 + 5072U);
    t10 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t16, t14, t18, t17);
    t3 = t10;
    goto LAB26;

LAB27:    t9 = (t0 + 1512U);
    t11 = *((char **)t9);
    t9 = (t0 + 5056U);
    t12 = (t0 + 1352U);
    t13 = *((char **)t12);
    t12 = (t0 + 5040U);
    t6 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t11, t9, t13, t12);
    t4 = t6;
    goto LAB29;

LAB30:    xsi_set_current_line(39, ng0);
    t19 = (t0 + 1672U);
    t21 = *((char **)t19);
    t19 = (t0 + 3392);
    t22 = (t19 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t21, 14U);
    xsi_driver_first_trans_fast_port(t19);
    goto LAB6;

LAB32:    t14 = (t0 + 1672U);
    t16 = *((char **)t14);
    t14 = (t0 + 5072U);
    t17 = (t0 + 1352U);
    t18 = *((char **)t17);
    t17 = (t0 + 5040U);
    t10 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t16, t14, t18, t17);
    t3 = t10;
    goto LAB34;

LAB35:    t9 = (t0 + 1672U);
    t11 = *((char **)t9);
    t9 = (t0 + 5072U);
    t12 = (t0 + 1512U);
    t13 = *((char **)t12);
    t12 = (t0 + 5056U);
    t6 = ieee_p_1242562249_sub_4081755647_1035706684(IEEE_P_1242562249, t11, t9, t13, t12);
    t4 = t6;
    goto LAB37;

LAB38:    xsi_size_not_matching(14U, 14U, 0);
    goto LAB39;

}


extern void work_a_1668467738_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1668467738_3212880686_p_0};
	xsi_register_didat("work_a_1668467738_3212880686", "isim/tb_main_isim_beh.exe.sim/work/a_1668467738_3212880686.didat");
	xsi_register_executes(pe);
}
