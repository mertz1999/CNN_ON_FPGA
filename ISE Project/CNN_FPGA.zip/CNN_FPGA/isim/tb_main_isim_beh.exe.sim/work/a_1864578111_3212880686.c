/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/FPGA/CNN_FPGA/Relu.vhd";
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_2563015576_1035706684(char *, char *, int , int );


static void work_a_1864578111_3212880686_p_0(char *t0)
{
    char t10[16];
    char *t1;
    char *t2;
    char *t3;
    int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned char t8;
    char *t9;
    char *t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    static char *nl0[] = {&&LAB7, &&LAB7, &&LAB6, &&LAB5, &&LAB7, &&LAB7, &&LAB7, &&LAB7, &&LAB7};

LAB0:    t1 = (t0 + 3312U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t4 = (13 - 13);
    t5 = (t4 * -1);
    t6 = (1U * t5);
    t7 = (0 + t6);
    t2 = (t3 + t7);
    t8 = *((unsigned char *)t2);
    t9 = (char *)((nl0) + t8);
    goto **((char **)t9);

LAB4:    xsi_set_current_line(36, ng0);

LAB14:    t2 = (t0 + 4376);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB15;

LAB1:    return;
LAB5:    xsi_set_current_line(37, ng0);
    t11 = ieee_p_1242562249_sub_2563015576_1035706684(IEEE_P_1242562249, t10, 0, 14);
    t12 = (14U != 14U);
    if (t12 == 1)
        goto LAB8;

LAB9:    t13 = (t0 + 4504);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t11, 14U);
    xsi_driver_first_trans_fast_port(t13);
    goto LAB4;

LAB6:    xsi_set_current_line(37, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 4504);
    t9 = (t2 + 56U);
    t11 = *((char **)t9);
    t13 = (t11 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t3, 14U);
    xsi_driver_first_trans_fast_port(t2);
    goto LAB4;

LAB7:    xsi_set_current_line(37, ng0);
    t2 = ieee_p_1242562249_sub_2563015576_1035706684(IEEE_P_1242562249, t10, 0, 14);
    t3 = (t10 + 12U);
    t5 = *((unsigned int *)t3);
    t5 = (t5 * 1U);
    t8 = (14U != t5);
    if (t8 == 1)
        goto LAB10;

LAB11:    t9 = (t0 + 4504);
    t11 = (t9 + 56U);
    t13 = *((char **)t11);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t2, 14U);
    xsi_driver_first_trans_fast_port(t9);
    goto LAB4;

LAB8:    xsi_size_not_matching(14U, 14U, 0);
    goto LAB9;

LAB10:    xsi_size_not_matching(14U, t5, 0);
    goto LAB11;

LAB12:    t3 = (t0 + 4376);
    *((int *)t3) = 0;
    goto LAB2;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

}

static void work_a_1864578111_3212880686_p_1(char *t0)
{
    char t10[16];
    char *t1;
    char *t2;
    char *t3;
    int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned char t8;
    char *t9;
    char *t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    static char *nl0[] = {&&LAB7, &&LAB7, &&LAB6, &&LAB5, &&LAB7, &&LAB7, &&LAB7, &&LAB7, &&LAB7};

LAB0:    t1 = (t0 + 3560U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t4 = (13 - 13);
    t5 = (t4 * -1);
    t6 = (1U * t5);
    t7 = (0 + t6);
    t2 = (t3 + t7);
    t8 = *((unsigned char *)t2);
    t9 = (char *)((nl0) + t8);
    goto **((char **)t9);

LAB4:    xsi_set_current_line(42, ng0);

LAB14:    t2 = (t0 + 4392);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB15;

LAB1:    return;
LAB5:    xsi_set_current_line(43, ng0);
    t11 = ieee_p_1242562249_sub_2563015576_1035706684(IEEE_P_1242562249, t10, 0, 14);
    t12 = (14U != 14U);
    if (t12 == 1)
        goto LAB8;

LAB9:    t13 = (t0 + 4568);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t11, 14U);
    xsi_driver_first_trans_fast_port(t13);
    goto LAB4;

LAB6:    xsi_set_current_line(43, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 4568);
    t9 = (t2 + 56U);
    t11 = *((char **)t9);
    t13 = (t11 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t3, 14U);
    xsi_driver_first_trans_fast_port(t2);
    goto LAB4;

LAB7:    xsi_set_current_line(43, ng0);
    t2 = ieee_p_1242562249_sub_2563015576_1035706684(IEEE_P_1242562249, t10, 0, 14);
    t3 = (t10 + 12U);
    t5 = *((unsigned int *)t3);
    t5 = (t5 * 1U);
    t8 = (14U != t5);
    if (t8 == 1)
        goto LAB10;

LAB11:    t9 = (t0 + 4568);
    t11 = (t9 + 56U);
    t13 = *((char **)t11);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t2, 14U);
    xsi_driver_first_trans_fast_port(t9);
    goto LAB4;

LAB8:    xsi_size_not_matching(14U, 14U, 0);
    goto LAB9;

LAB10:    xsi_size_not_matching(14U, t5, 0);
    goto LAB11;

LAB12:    t3 = (t0 + 4392);
    *((int *)t3) = 0;
    goto LAB2;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

}

static void work_a_1864578111_3212880686_p_2(char *t0)
{
    char t10[16];
    char *t1;
    char *t2;
    char *t3;
    int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned char t8;
    char *t9;
    char *t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    static char *nl0[] = {&&LAB7, &&LAB7, &&LAB6, &&LAB5, &&LAB7, &&LAB7, &&LAB7, &&LAB7, &&LAB7};

LAB0:    t1 = (t0 + 3808U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t4 = (13 - 13);
    t5 = (t4 * -1);
    t6 = (1U * t5);
    t7 = (0 + t6);
    t2 = (t3 + t7);
    t8 = *((unsigned char *)t2);
    t9 = (char *)((nl0) + t8);
    goto **((char **)t9);

LAB4:    xsi_set_current_line(48, ng0);

LAB14:    t2 = (t0 + 4408);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB15;

LAB1:    return;
LAB5:    xsi_set_current_line(49, ng0);
    t11 = ieee_p_1242562249_sub_2563015576_1035706684(IEEE_P_1242562249, t10, 0, 14);
    t12 = (14U != 14U);
    if (t12 == 1)
        goto LAB8;

LAB9:    t13 = (t0 + 4632);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t11, 14U);
    xsi_driver_first_trans_fast_port(t13);
    goto LAB4;

LAB6:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t2 = (t0 + 4632);
    t9 = (t2 + 56U);
    t11 = *((char **)t9);
    t13 = (t11 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t3, 14U);
    xsi_driver_first_trans_fast_port(t2);
    goto LAB4;

LAB7:    xsi_set_current_line(49, ng0);
    t2 = ieee_p_1242562249_sub_2563015576_1035706684(IEEE_P_1242562249, t10, 0, 14);
    t3 = (t10 + 12U);
    t5 = *((unsigned int *)t3);
    t5 = (t5 * 1U);
    t8 = (14U != t5);
    if (t8 == 1)
        goto LAB10;

LAB11:    t9 = (t0 + 4632);
    t11 = (t9 + 56U);
    t13 = *((char **)t11);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t2, 14U);
    xsi_driver_first_trans_fast_port(t9);
    goto LAB4;

LAB8:    xsi_size_not_matching(14U, 14U, 0);
    goto LAB9;

LAB10:    xsi_size_not_matching(14U, t5, 0);
    goto LAB11;

LAB12:    t3 = (t0 + 4408);
    *((int *)t3) = 0;
    goto LAB2;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

}

static void work_a_1864578111_3212880686_p_3(char *t0)
{
    char t10[16];
    char *t1;
    char *t2;
    char *t3;
    int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned char t8;
    char *t9;
    char *t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    static char *nl0[] = {&&LAB7, &&LAB7, &&LAB6, &&LAB5, &&LAB7, &&LAB7, &&LAB7, &&LAB7, &&LAB7};

LAB0:    t1 = (t0 + 4056U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(54, ng0);
    t2 = (t0 + 1512U);
    t3 = *((char **)t2);
    t4 = (13 - 13);
    t5 = (t4 * -1);
    t6 = (1U * t5);
    t7 = (0 + t6);
    t2 = (t3 + t7);
    t8 = *((unsigned char *)t2);
    t9 = (char *)((nl0) + t8);
    goto **((char **)t9);

LAB4:    xsi_set_current_line(54, ng0);

LAB14:    t2 = (t0 + 4424);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB15;

LAB1:    return;
LAB5:    xsi_set_current_line(55, ng0);
    t11 = ieee_p_1242562249_sub_2563015576_1035706684(IEEE_P_1242562249, t10, 0, 14);
    t12 = (14U != 14U);
    if (t12 == 1)
        goto LAB8;

LAB9:    t13 = (t0 + 4696);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t11, 14U);
    xsi_driver_first_trans_fast_port(t13);
    goto LAB4;

LAB6:    xsi_set_current_line(55, ng0);
    t2 = (t0 + 1512U);
    t3 = *((char **)t2);
    t2 = (t0 + 4696);
    t9 = (t2 + 56U);
    t11 = *((char **)t9);
    t13 = (t11 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t3, 14U);
    xsi_driver_first_trans_fast_port(t2);
    goto LAB4;

LAB7:    xsi_set_current_line(55, ng0);
    t2 = ieee_p_1242562249_sub_2563015576_1035706684(IEEE_P_1242562249, t10, 0, 14);
    t3 = (t10 + 12U);
    t5 = *((unsigned int *)t3);
    t5 = (t5 * 1U);
    t8 = (14U != t5);
    if (t8 == 1)
        goto LAB10;

LAB11:    t9 = (t0 + 4696);
    t11 = (t9 + 56U);
    t13 = *((char **)t11);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t2, 14U);
    xsi_driver_first_trans_fast_port(t9);
    goto LAB4;

LAB8:    xsi_size_not_matching(14U, 14U, 0);
    goto LAB9;

LAB10:    xsi_size_not_matching(14U, t5, 0);
    goto LAB11;

LAB12:    t3 = (t0 + 4424);
    *((int *)t3) = 0;
    goto LAB2;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

}


extern void work_a_1864578111_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1864578111_3212880686_p_0,(void *)work_a_1864578111_3212880686_p_1,(void *)work_a_1864578111_3212880686_p_2,(void *)work_a_1864578111_3212880686_p_3};
	xsi_register_didat("work_a_1864578111_3212880686", "isim/tb_main_isim_beh.exe.sim/work/a_1864578111_3212880686.didat");
	xsi_register_executes(pe);
}
